"""
Utility modules for the Document Translator application.
"""

