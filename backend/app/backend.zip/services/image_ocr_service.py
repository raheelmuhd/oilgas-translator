"""
Cascading Image OCR Service (Generalized)
==========================================
Extracts text from PDF images using a cascading approach for best accuracy:

1. Tesseract (fastest, good for clean typed text)
2. PaddleOCR (if Tesseract confidence < 70%)
3. Ollama Vision minicpm-v (if still < 70%, best for handwritten/complex)

Automatically adapts to any source language - no hardcoded language dependencies.
"""

import asyncio
import base64
import io
import os
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
import logging

import httpx
from PIL import Image, ImageEnhance, ImageFilter

logger = logging.getLogger(__name__)

# Confidence threshold to try next backend (90% = high quality requirement)
CONFIDENCE_THRESHOLD = 0.90


@dataclass
class ImageOCRResult:
    """Result from OCR operation on an image."""
    original_text: str
    translated_text: str
    confidence: float
    backend_used: str
    language_detected: str = ""


class ImagePreprocessor:
    """Preprocesses images to improve OCR accuracy."""
    
    @staticmethod
    def enhance_for_ocr(image: Image.Image) -> Image.Image:
        """Apply preprocessing to improve OCR accuracy."""
        if image.mode not in ('RGB', 'L'):
            image = image.convert('RGB')
        
        gray = image.convert('L')
        enhancer = ImageEnhance.Contrast(gray)
        gray = enhancer.enhance(1.5)
        gray = gray.filter(ImageFilter.SHARPEN)
        gray = gray.filter(ImageFilter.MedianFilter(size=3))
        
        return gray
    
    @staticmethod
    def resize_for_ocr(image: Image.Image, min_width: int = 1000) -> Image.Image:
        """Resize image to optimal size for OCR."""
        if image.width < min_width:
            scale = min_width / image.width
            new_size = (int(image.width * scale), int(image.height * scale))
            image = image.resize(new_size, Image.Resampling.LANCZOS)
        return image


# =============================================================================
# LANGUAGE MAPPING - Comprehensive mapping for all supported languages
# =============================================================================
# ISO 639-1 to Tesseract language codes
TESSERACT_LANG_MAP = {
    # Slavic languages
    'uk': 'ukr', 'ru': 'rus', 'hr': 'hrv', 'sr': 'srp', 'sl': 'slv',
    'pl': 'pol', 'cs': 'ces', 'sk': 'slk', 'bg': 'bul', 'mk': 'mkd',
    'be': 'bel', 'bs': 'bos',
    # Western European
    'en': 'eng', 'de': 'deu', 'fr': 'fra', 'es': 'spa', 'it': 'ita',
    'pt': 'por', 'nl': 'nld', 'da': 'dan', 'sv': 'swe', 'no': 'nor',
    'fi': 'fin', 'is': 'isl',
    # Eastern European
    'ro': 'ron', 'hu': 'hun', 'et': 'est', 'lv': 'lav', 'lt': 'lit',
    # Asian
    'zh': 'chi_sim', 'ja': 'jpn', 'ko': 'kor', 'vi': 'vie', 'th': 'tha',
    'ar': 'ara', 'he': 'heb', 'hi': 'hin', 'bn': 'ben', 'ta': 'tam',
    # Other
    'tr': 'tur', 'el': 'ell', 'ka': 'kat', 'hy': 'hye', 'az': 'aze',
}

# ISO 639-1 to PaddleOCR language/script
PADDLE_LANG_MAP = {
    # Latin script languages
    'en': 'en', 'de': 'german', 'fr': 'french', 'es': 'spanish',
    'it': 'italian', 'pt': 'pt', 'nl': 'nl', 'pl': 'polish',
    # Cyrillic script
    'uk': 'cyrillic', 'ru': 'cyrillic', 'bg': 'cyrillic', 'sr': 'cyrillic',
    'be': 'cyrillic', 'mk': 'cyrillic',
    # Latin script (Slavic)
    'hr': 'latin', 'sl': 'latin', 'cs': 'latin', 'sk': 'latin',
    'bs': 'latin',
    # Asian
    'zh': 'ch', 'ja': 'japan', 'ko': 'korean', 'ar': 'ar',
    # Default
    'default': 'en'
}

# Language names for Ollama Vision prompts
LANGUAGE_NAMES = {
    'uk': 'Ukrainian', 'ru': 'Russian', 'hr': 'Croatian', 'sr': 'Serbian',
    'sl': 'Slovenian', 'pl': 'Polish', 'cs': 'Czech', 'sk': 'Slovak',
    'bg': 'Bulgarian', 'mk': 'Macedonian', 'be': 'Belarusian', 'bs': 'Bosnian',
    'en': 'English', 'de': 'German', 'fr': 'French', 'es': 'Spanish',
    'it': 'Italian', 'pt': 'Portuguese', 'nl': 'Dutch', 'da': 'Danish',
    'sv': 'Swedish', 'no': 'Norwegian', 'fi': 'Finnish',
    'ro': 'Romanian', 'hu': 'Hungarian', 'et': 'Estonian', 'lv': 'Latvian',
    'lt': 'Lithuanian', 'zh': 'Chinese', 'ja': 'Japanese', 'ko': 'Korean',
    'ar': 'Arabic', 'he': 'Hebrew', 'hi': 'Hindi', 'tr': 'Turkish',
    'el': 'Greek', 'th': 'Thai', 'vi': 'Vietnamese',
}


# =============================================================================
# BACKEND 1: TESSERACT (Fastest)
# =============================================================================
class TesseractOCR:
    """Tesseract OCR - fast, good for clean typed documents."""
    
    def __init__(self):
        self._available = None
        self._installed_languages = None
    
    def is_available(self) -> bool:
        if self._available is not None:
            return self._available
        
        try:
            import pytesseract
            pytesseract.get_tesseract_version()
            self._installed_languages = pytesseract.get_languages()
            self._available = True
            logger.info(f"Tesseract available with {len(self._installed_languages)} languages: {self._installed_languages}")
        except Exception as e:
            logger.warning(f"Tesseract not available: {e}")
            self._available = False
        
        return self._available
    
    def get_lang_string(self, source_lang: str, additional_langs: List[str] = None) -> str:
        """
        Build Tesseract language string from source language.
        Automatically uses installed languages only.
        """
        if not self._installed_languages:
            return 'eng'
        
        langs_to_use = []
        
        # Add source language if available
        if source_lang:
            tess_lang = TESSERACT_LANG_MAP.get(source_lang, source_lang)
            if tess_lang in self._installed_languages:
                langs_to_use.append(tess_lang)
            # Try 3-letter code directly
            elif source_lang in self._installed_languages:
                langs_to_use.append(source_lang)
        
        # Add additional languages
        if additional_langs:
            for lang in additional_langs:
                tess_lang = TESSERACT_LANG_MAP.get(lang, lang)
                if tess_lang in self._installed_languages and tess_lang not in langs_to_use:
                    langs_to_use.append(tess_lang)
        
        # Always include English as fallback if available
        if 'eng' in self._installed_languages and 'eng' not in langs_to_use:
            langs_to_use.append('eng')
        
        result = '+'.join(langs_to_use) if langs_to_use else 'eng'
        logger.debug(f"Tesseract using languages: {result}")
        return result
    
    def extract_text(self, image: Image.Image, source_lang: str = None) -> Tuple[str, float]:
        """Extract text with confidence score."""
        import pytesseract
        
        lang_str = self.get_lang_string(source_lang)
        
        try:
            data = pytesseract.image_to_data(
                image, lang=lang_str, output_type=pytesseract.Output.DICT
            )
            
            texts = []
            confidences = []
            
            for i, text in enumerate(data['text']):
                if text and str(text).strip():
                    texts.append(str(text).strip())
                    conf = int(data['conf'][i])
                    if conf > 0:
                        confidences.append(conf)
            
            full_text = ' '.join(texts)
            avg_conf = sum(confidences) / len(confidences) / 100.0 if confidences else 0.0
            
            return full_text, avg_conf
            
        except Exception as e:
            logger.error(f"Tesseract failed: {e}")
            return "", 0.0


# =============================================================================
# BACKEND 2: PADDLEOCR (Better for complex layouts)
# =============================================================================
class PaddleOCRBackend:
    """PaddleOCR - better for tables and complex layouts."""
    
    def __init__(self):
        self._ocr_instances = {}  # Cache OCR instances per language
        self._available = None
        self._init_attempted = False
    
    def is_available(self) -> bool:
        if self._available is not None:
            return self._available
        
        try:
            os.environ['DISABLE_MODEL_SOURCE_CHECK'] = 'True'
            from paddleocr import PaddleOCR
            self._available = True
            logger.info("PaddleOCR available")
        except ImportError:
            self._available = False
        except Exception as e:
            self._available = False
            logger.warning(f"PaddleOCR error: {e}")
        
        return self._available
    
    def _get_ocr(self, source_lang: str = None):
        """Get or create PaddleOCR instance for the given language."""
        paddle_lang = PADDLE_LANG_MAP.get(source_lang, PADDLE_LANG_MAP.get('default', 'en'))
        
        if paddle_lang not in self._ocr_instances:
            try:
                from paddleocr import PaddleOCR
                self._ocr_instances[paddle_lang] = PaddleOCR(
                    lang=paddle_lang, 
                    use_angle_cls=False, 
                    use_gpu=True,
                    show_log=False
                )
                logger.info(f"PaddleOCR initialized for lang={paddle_lang}")
            except Exception as e:
                logger.error(f"PaddleOCR init failed for {paddle_lang}: {e}")
                # Try with 'en' as fallback
                if paddle_lang != 'en' and 'en' not in self._ocr_instances:
                    try:
                        from paddleocr import PaddleOCR
                        self._ocr_instances['en'] = PaddleOCR(lang='en', use_angle_cls=False, use_gpu=True)
                        paddle_lang = 'en'
                    except:
                        return None
                elif 'en' in self._ocr_instances:
                    paddle_lang = 'en'
                else:
                    return None
        
        return self._ocr_instances.get(paddle_lang)
    
    def extract_text(self, image: Image.Image, source_lang: str = None) -> Tuple[str, float]:
        """Extract text with confidence score."""
        try:
            import numpy as np
            
            ocr = self._get_ocr(source_lang)
            if ocr is None:
                return "", 0.0
            
            img_array = np.array(image.convert('RGB'))
            result = ocr.ocr(img_array, cls=False)
            
            texts = []
            confidences = []
            
            if result and result[0]:
                for line in result[0]:
                    if len(line) >= 2:
                        text_conf = line[1]
                        if isinstance(text_conf, (list, tuple)) and len(text_conf) >= 2:
                            text, conf = str(text_conf[0]), float(text_conf[1])
                        else:
                            text, conf = str(text_conf), 0.8
                        
                        if text.strip():
                            texts.append(text.strip())
                            confidences.append(conf)
            
            full_text = ' '.join(texts)
            avg_conf = sum(confidences) / len(confidences) if confidences else 0.0
            
            return full_text, avg_conf
            
        except Exception as e:
            logger.error(f"PaddleOCR failed: {e}")
            return "", 0.0


# =============================================================================
# BACKEND 3: OLLAMA VISION (Best accuracy, uses GPU)
# =============================================================================
class OllamaVisionOCR:
    """Ollama Vision OCR using minicpm-v - best for handwritten/complex docs."""
    
    def __init__(self, base_url: str = "http://localhost:11434", model: str = "minicpm-v"):
        self.base_url = base_url.rstrip('/')
        self.model = model
        self._available = None
    
    async def is_available(self) -> bool:
        if self._available is not None:
            return self._available
        
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                response = await client.get(f"{self.base_url}/api/tags")
                if response.status_code == 200:
                    models = [m.get('name', '').split(':')[0] for m in response.json().get('models', [])]
                    self._available = self.model in models or any(self.model in m for m in models)
                    if self._available:
                        logger.info(f"Ollama Vision available: {self.model}")
                    return self._available
        except Exception as e:
            logger.debug(f"Ollama not available: {e}")
        
        self._available = False
        return False
    
    def _image_to_base64(self, image: Image.Image) -> str:
        max_dim = 2048
        if image.width > max_dim or image.height > max_dim:
            ratio = min(max_dim / image.width, max_dim / image.height)
            new_size = (int(image.width * ratio), int(image.height * ratio))
            image = image.resize(new_size, Image.Resampling.LANCZOS)
        
        if image.mode not in ('RGB', 'L'):
            image = image.convert('RGB')
        
        buffer = io.BytesIO()
        image.save(buffer, format='PNG', optimize=True)
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    async def extract_text(self, image: Image.Image, source_lang: str = None) -> Tuple[str, float]:
        """Extract text using Ollama Vision model."""
        image_b64 = self._image_to_base64(image)
        
        # Get human-readable language name
        lang_name = LANGUAGE_NAMES.get(source_lang, source_lang) if source_lang else None
        lang_hint = f"The document is in {lang_name}. " if lang_name else ""
        
        prompt = f"""{lang_hint}Extract ALL text from this document image exactly as written.
Include every word, number, date. For tables use | separators.
Include handwritten text. Do NOT translate. Output only the extracted text:"""

        try:
            async with httpx.AsyncClient(timeout=120) as client:
                response = await client.post(
                    f"{self.base_url}/api/generate",
                    json={
                        "model": self.model,
                        "prompt": prompt,
                        "images": [image_b64],
                        "stream": False,
                        "options": {"temperature": 0.1, "num_predict": 4096}
                    }
                )
                
                if response.status_code == 200:
                    text = response.json().get('response', '').strip()
                    # Clean common prefixes
                    for prefix in ["Here is the extracted text:", "Extracted text:", "Text:"]:
                        if text.lower().startswith(prefix.lower()):
                            text = text[len(prefix):].strip()
                    
                    logger.info(f"Ollama Vision extracted {len(text)} chars")
                    return text, 0.95
                    
        except Exception as e:
            logger.error(f"Ollama Vision failed: {e}")
        
        return "", 0.0


# =============================================================================
# MAIN CASCADING SERVICE
# =============================================================================
class ImageOCRService:
    """
    Cascading OCR Service - tries backends in order until good accuracy achieved.
    
    Order: Tesseract → PaddleOCR → Ollama Vision (minicpm-v)
    
    Automatically adapts to any source language.
    """
    
    def __init__(
        self,
        translation_service=None,
        settings=None,
        confidence_threshold: float = CONFIDENCE_THRESHOLD
    ):
        self.translation_service = translation_service
        self.settings = settings
        self.confidence_threshold = confidence_threshold
        self.preprocessor = ImagePreprocessor()
        
        # Initialize backends
        self.tesseract = TesseractOCR()
        self.paddleocr = PaddleOCRBackend()
        
        ollama_url = getattr(settings, 'ollama_base_url', 'http://localhost:11434') if settings else 'http://localhost:11434'
        self.ollama_vision = OllamaVisionOCR(base_url=ollama_url, model="minicpm-v")
        
        # Log availability
        backends = []
        if self.tesseract.is_available():
            backends.append("Tesseract")
        if self.paddleocr.is_available():
            backends.append("PaddleOCR")
        
        logger.info(f"Cascading OCR initialized: {backends} (+ Ollama Vision checked async)")
    
    def is_available(self) -> bool:
        return self.tesseract.is_available() or self.paddleocr.is_available()
    
    async def extract_text_cascading(
        self,
        image: Image.Image,
        source_lang: str = None
    ) -> Tuple[str, float, str]:
        """
        Try OCR backends in cascade until good accuracy achieved.
        
        Args:
            image: PIL Image to process
            source_lang: ISO 639-1 language code (e.g., 'uk', 'hr', 'en')
        
        Returns: (text, confidence, backend_used)
        """
        # Preprocess image
        img_enhanced = self.preprocessor.enhance_for_ocr(image)
        img_resized = self.preprocessor.resize_for_ocr(img_enhanced)
        
        # ===== STEP 1: Try Tesseract (fastest) =====
        if self.tesseract.is_available():
            text, conf = self.tesseract.extract_text(img_resized, source_lang)
            logger.info(f"Tesseract: {len(text)} chars, {conf:.0%} confidence")
            
            if conf >= self.confidence_threshold and len(text) > 20:
                return text, conf, "tesseract"
        
        # ===== STEP 2: Try PaddleOCR (better for complex layouts) =====
        if self.paddleocr.is_available():
            text, conf = self.paddleocr.extract_text(img_resized, source_lang)
            logger.info(f"PaddleOCR: {len(text)} chars, {conf:.0%} confidence")
            
            if conf >= self.confidence_threshold and len(text) > 20:
                return text, conf, "paddleocr"
        
        # ===== STEP 3: Try Ollama Vision (best accuracy, GPU) =====
        if await self.ollama_vision.is_available():
            text, conf = await self.ollama_vision.extract_text(image, source_lang)
            logger.info(f"Ollama Vision: {len(text)} chars, {conf:.0%} confidence")
            
            if text:
                return text, conf, "ollama_vision"
        
        # ===== Fallback: Return best result we got =====
        if self.tesseract.is_available():
            text, conf = self.tesseract.extract_text(image, source_lang)
            if text:
                return text, conf, "tesseract_fallback"
        
        return "", 0.0, "none"
    
    async def extract_and_translate(
        self,
        image_data: bytes,
        source_lang: str = None,
        target_lang: str = "en"
    ) -> ImageOCRResult:
        """Full pipeline: Extract text then translate."""
        try:
            img = Image.open(io.BytesIO(image_data))
            
            if img.width < 50 or img.height < 50:
                return ImageOCRResult("", "", 0.0, "skipped")
            
            original_text, confidence, backend = await self.extract_text_cascading(img, source_lang)
            
            if not original_text:
                return ImageOCRResult("", "", 0.0, backend)
            
            # Translate
            translated_text = original_text
            if self.translation_service and source_lang != target_lang:
                try:
                    if hasattr(self.translation_service, 'translate_if_needed'):
                        result, _, was_translated = await self.translation_service.translate_if_needed(
                            original_text, source_lang or "auto", target_lang, None
                        )
                        if was_translated:
                            translated_text = result
                except Exception as e:
                    logger.warning(f"Translation failed: {e}")
            
            return ImageOCRResult(
                original_text=original_text,
                translated_text=translated_text,
                confidence=confidence,
                backend_used=backend,
                language_detected=source_lang or ""
            )
            
        except Exception as e:
            logger.error(f"OCR pipeline failed: {e}")
            return ImageOCRResult("", "", 0.0, "error")
    
    async def process_page_images(
        self,
        page_images: List[Dict],
        source_lang: str = None,
        target_lang: str = "en"
    ) -> List[Dict]:
        """Process all images from a page."""
        for img in page_images:
            img_data = img.get('data') or img.get('bytes')
            if not img_data:
                continue
            
            try:
                result = await self.extract_and_translate(img_data, source_lang, target_lang)
                
                img['ocr_text'] = result.original_text
                img['translated_text'] = result.translated_text
                img['ocr_confidence'] = result.confidence
                img['ocr_backend'] = result.backend_used
                
                if result.translated_text:
                    img['image_label'] = f"[IMAGE TEXT TRANSLATION]\n{result.translated_text}"
                    logger.info(f"Image OCR ({result.backend_used}, {result.confidence:.0%}): {len(result.original_text)} chars")
                else:
                    img['image_label'] = ""
                    
            except Exception as e:
                logger.warning(f"Image processing failed: {e}")
                img['ocr_text'] = ""
                img['translated_text'] = ""
                img['image_label'] = ""
        
        return page_images


async def process_all_images(
    all_page_images: List[List[Dict]],
    translation_service=None,
    source_lang: str = None,
    target_lang: str = "en",
    settings=None,
    progress_callback=None
) -> List[List[Dict]]:
    """Process images from all pages with cascading OCR."""
    service = ImageOCRService(translation_service, settings)
    
    if not service.is_available():
        logger.warning("No OCR backend available")
        return all_page_images
    
    total_images = sum(len(imgs) for imgs in all_page_images)
    if total_images == 0:
        return all_page_images
    
    lang_name = LANGUAGE_NAMES.get(source_lang, source_lang) if source_lang else "auto"
    logger.info(f"Processing {total_images} images with cascading OCR (lang={lang_name})")
    
    processed = []
    images_done = 0
    backend_stats = {"tesseract": 0, "paddleocr": 0, "ollama_vision": 0, "none": 0}
    
    for page_idx, page_images in enumerate(all_page_images):
        if page_images:
            processed_page = await service.process_page_images(page_images, source_lang, target_lang)
            processed.append(processed_page)
            
            for img in processed_page:
                backend = img.get('ocr_backend', 'none')
                if backend in backend_stats:
                    backend_stats[backend] += 1
                elif 'tesseract' in backend:
                    backend_stats['tesseract'] += 1
            
            images_done += len(page_images)
            if progress_callback:
                progress_callback(f"OCR: {images_done}/{total_images}")
        else:
            processed.append([])
    
    images_with_text = sum(1 for page in processed for img in page if img.get('translated_text'))
    logger.info(f"OCR complete: {images_with_text}/{total_images} images had text")
    logger.info(f"Backend usage: Tesseract={backend_stats['tesseract']}, PaddleOCR={backend_stats['paddleocr']}, Ollama={backend_stats['ollama_vision']}")
    
    return processed
