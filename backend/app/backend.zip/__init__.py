# Oil & Gas Document Translator Backend

